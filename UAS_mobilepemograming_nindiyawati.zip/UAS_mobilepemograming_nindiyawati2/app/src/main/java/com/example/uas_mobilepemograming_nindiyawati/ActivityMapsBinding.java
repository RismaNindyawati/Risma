package com.example.uas_mobilepemograming_nindiyawati;

import android.view.LayoutInflater;

public class ActivityMapsBinding {
    public static ActivityMapsBinding inflate(Object inflater) {
        return null;
    }

    public int getRoot() {
        return 0;
    }
}
